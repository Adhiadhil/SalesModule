package com.projects.authentication;

import java.util.Date;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.transaction.Transactional;

public interface UserRepository extends JpaRepository<User, Integer> {

  Optional<User> findByEmail(String email);
  
  @Modifying(clearAutomatically = true)
  @Transactional
  @Query("Update User u Set u.password=:pwd Where u.id=:id")
  int updateUserPassword(@Param("pwd") String password, @Param("id") int id);
  
  @Modifying
  @Transactional
  @Query("Update User u Set u.active=:active, u.locked=:locked, startDate=:sdate, endDate=:edate WHERE u.id=:id")
  int updateUserStatus(@Param("active") boolean active, @Param("locked") boolean locked, @Param("sdate") Date sdate, @Param("edate") Date edate, @Param("id") int id);

}
