package com.projects.authentication;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.data.domain.Sort;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserService {

	private final UserRepository repository;
	private final PasswordEncoder passwordEncoder;
	private final UserDetailsService userDetailsService;
	
	public User getUserBymail(String mail) {
		User user= (User) userDetailsService.loadUserByUsername(mail);
		log.info("Userdetails {}",user.getId());
		return user;
	}
	
	public Optional<User> getUserById(int Id) {
		Optional<User> user= repository.findById(Id);
		return user;
	}
	
	public int changePassword(int id, String pwd) {
		return repository.updateUserPassword(passwordEncoder.encode(pwd), id);
	}
	
	
	
	public int updateStatus(boolean active, boolean locked, Date sdate, Date edate, int id) {
		if(sdate.after(edate)) {
			return 0;
		}else {
			return repository.updateUserStatus(active, locked, sdate, edate, id);
		}
	}
}
