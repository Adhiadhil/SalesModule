package com.projects.authentication;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.projects.token.Token;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="m_user")
@Slf4j
public class User implements UserDetails {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;
  @Column(nullable = false)
  private String name;
 
  @Column(nullable = false)
  private boolean active;
  @Column(nullable= false)
  private boolean locked;
  @Column(nullable = false, unique = true)
  private String email;
  @Column(nullable=false)
  private String password;

  @Enumerated(EnumType.STRING)
  private Role role;

  @OneToMany(mappedBy = "user")
  private List<Token> tokens;
  
  private Date startDate;
  private Date endDate;
  

  @Override
  public Collection<? extends GrantedAuthority> getAuthorities() {
	  log.info("Roles :{}",role);
    return role.getAuthorities();
  }

  @Override
  public String getPassword() {
    return password;
  }

  @Override
  public String getUsername() {
    return email;
  }

  @Override
  public boolean isAccountNonExpired() {
	  Date today = new Date(System.currentTimeMillis());
	  Boolean stat1 = today.after(startDate); 
	  Boolean stat2 = today.before(endDate); 
	  System.out.println("isAccountNonExpired"+ today + stat1 + stat2);
	  return  stat1&&stat2;
  }

  @Override
  public boolean isAccountNonLocked() {
    return !locked;
  }

  @Override
  public boolean isCredentialsNonExpired() {
	  Date today = new Date(System.currentTimeMillis());
	  Boolean stat = today.after(startDate) && today.before(endDate);
	  System.out.println("isCredentialsNonExpired"+ stat);
	  return  stat;
	  
  }

  @Override
  public boolean isEnabled() {
    return active;
  }
}
