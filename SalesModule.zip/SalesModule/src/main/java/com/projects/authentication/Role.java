package com.projects.authentication;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.security.core.authority.SimpleGrantedAuthority;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum Role {

  USER_DE(
		  Set.of(
		  	Permission.REGISTRATION_READ,
		  	Permission.PARTICIPANT_READ,
		  	Permission.PARTICIPANT_UPDATE,
		  	Permission.SOCIETY_READ
		  )
		  ),
  USER_RE(
		  Set.of(
				  	Permission.REGISTRATION_READ,
				  	Permission.PARTICIPANT_READ,
				  	Permission.REGISTRATION_CREATE,
				  	Permission.SOCIETY_READ,
				  	Permission.REGISTRATION_UPDATE
				  )
		  
		  ),
  ADMIN(
		  Set.of(

				  Permission.REGISTRATION_READ,
				  Permission.REGISTRATION_CREATE,
				  Permission.REGISTRATION_UPDATE,
				  Permission.REGISTRATION_DELETE,
					
				  Permission.SOCIETY_READ,
				  Permission.SOCIETY_CREATE,
				  Permission.SOCIETY_UPDATE,
				  Permission.SOCIETY_DELETE,
					
				  Permission.PARTICIPANT_READ,
				  Permission.PARTICIPANT_CREATE,
				  Permission.PARTICIPANT_UPDATE,
				  Permission.PARTICIPANT_DELETE
				  
				  )
		  ),
  MANAGER(
		  Set.of(
				 
				  Permission.REGISTRATION_READ,
				  Permission.SOCIETY_READ,		
				  Permission.PARTICIPANT_READ 
				  )
		  )
  ;
  
 @Getter
  private final Set<Permission> permissions;
 
 public List<SimpleGrantedAuthority> getAuthorities(){
	 
	 var authorities= getPermissions().stream()
			 .map((permission)->{
				 return new SimpleGrantedAuthority(permission.getPermission());
			 }).collect(Collectors.toList());
	 authorities.add(new SimpleGrantedAuthority("ROLE_"+this.name()));
	 return authorities;
 }
  
}
