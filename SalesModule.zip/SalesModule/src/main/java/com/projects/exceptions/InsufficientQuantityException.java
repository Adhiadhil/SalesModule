package com.projects.exceptions;

public class InsufficientQuantityException extends Exception{

	public InsufficientQuantityException(String msg) {
		super(msg);
	}
}
