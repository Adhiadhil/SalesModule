package com.projects.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.projects.dto.APIResponse;
import com.projects.dto.SaleRequestDTO;
import com.projects.exceptions.InsufficientQuantityException;
import com.projects.exceptions.ProductNotFoundException;
import com.projects.model.Product;
import com.projects.model.Sale;
import com.projects.repository.ProductRepository;
import com.projects.repository.SaleRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductServiceImpl implements ProductService{
	
	private final ProductRepository productRepository;
	private final SaleRepository saleRepository;


	@Override
	public List<Product> getAllProducts() {
		return productRepository.findAll() ;
	}

	@Override
	public Product getProductById(int id) throws ProductNotFoundException {
		return productRepository.findById(id).orElseThrow(()-> new ProductNotFoundException("Invalid Product Code!")) ;
	}

	@Override
	public Product addProduct(Product product) {
		return productRepository.save(product);
	}

	@Override
	public Product updateProduct(int id, Product product) {
		product.setId(id);
		return productRepository.save(product);
	}

	@Override
	public void deleteProduct(int id) {
		productRepository.deleteById(id);
	}
	
	@Override
	public Sale generateSale(SaleRequestDTO saleRequest) throws ProductNotFoundException, InsufficientQuantityException {
		log.info("New Sale Creating...");
		Product product = productRepository.findById(saleRequest.getProductId()).orElseThrow(()-> new ProductNotFoundException("No product Found"));
		int saleQuantity = product.getSales().stream().mapToInt(Sale::getQuantity).sum();
		int totalQuantity = product.getQuantity();
		int requiredQuantity = saleRequest.getQuantity();
		
		if(saleQuantity+ requiredQuantity > totalQuantity) {
			throw new InsufficientQuantityException("Insufficient quantity available for Product "+ product.getName());
		}
		Sale s= Sale.builder()
				.productId(product)
				.quantity(saleRequest.getQuantity())
				.saleDate(saleRequest.getSaleDate())
				.build();
		return saleRepository.save(s);
	}

	@Override
	public APIResponse getTotalRevenue() {
		List<Product> products = productRepository.findAll();
		Double revenue= products.stream()
				.flatMap(product-> product.getSales().stream())
				.mapToDouble(s -> s.getProductId().getPrice() * s.getQuantity())
				.sum();
		return new APIResponse("Total Revenue", revenue);
		
	}

	@Override
	public APIResponse getRevenueByProduct(int productId) throws ProductNotFoundException {
		Product products = productRepository.findById(productId).orElseThrow(()-> new ProductNotFoundException("Invalid Product Code"));
		Double revenue = products.getSales().stream().mapToDouble(sale->
											sale.getQuantity() * sale.getProductId().getPrice()
				).sum() ;
		return new APIResponse("Total Revenue of Product "+products.getName(), revenue );
	}


}
