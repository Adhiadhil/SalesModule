package com.projects.token;

public enum TokenType {
  BEARER
}
